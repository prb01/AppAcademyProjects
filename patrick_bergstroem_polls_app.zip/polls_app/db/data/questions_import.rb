Question.import(
    [:question, :poll_id],
    [['Should stablecoins be allowed?', 1],
    ['Is lawsuit against XRP warranted?', 1],
    ['Should SEC regulate ALL crypto market?', 1],
    ['Do you think US is falling behind in crypto regulation?', 1],
    ['Where should masks be worn?', 2],
    ['Should vaccinations be mandated?', 2],
    ['Do you believe in COVID conspiracies?', 2],
    ['Should Russia be warned?', 3],
    ['Should Iran be allowed to do nuclear stuff?', 3],
    ['Should North Korea be taken seriously?', 3]]
  )