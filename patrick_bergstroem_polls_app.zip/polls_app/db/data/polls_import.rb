Poll.import(
    [:title, :author_id],
    [['Crypto', 1],
    ['Covid-19 measures', 1],
    ['Foreign policy', 2]]
  )